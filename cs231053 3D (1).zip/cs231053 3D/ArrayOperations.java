import java.util.Arrays;
import java.util.Scanner;

public class ArrayOperations {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 1. Declaration and Initialization
        int[] array = new int[5];
        System.out.println("Enter 5 elements for the array:");
        for (int i = 0; i < array.length; i++) {
            array[i] = scanner.nextInt();
        }

        // 2. Add an element to the array (Resize array first)
        array = addElement(array, 10);
        System.out.println("Array after adding element: " + Arrays.toString(array));

        // 3. Edit an element in the array
        editElement(array, 2, 99);
        System.out.println("Array after editing element: " + Arrays.toString(array));

        // 4. Delete an element from the array
        array = deleteElement(array, 2);
        System.out.println("Array after deleting element: " + Arrays.toString(array));

        // 5. Reverse the array
        reverseArray(array);
        System.out.println("Array after reversing: " + Arrays.toString(array));

        // 6. Find minimum value in the array
        int min = findMinValue(array);
        System.out.println("Minimum value in the array: " + min);

        // 7. Find the second maximum value in the array
        int secondMax = findSecondMax(array);
        System.out.println("Second maximum value in the array: " + secondMax);

        // 8. Move zeroes to the end
        moveZeroesToEnd(array);
        System.out.println("Array after moving zeroes to the end: " + Arrays.toString(array));

        // 9. Resize the array (Increase size)
        array = resizeArray(array, 10); 
        System.out.println("Array after resizing: " + Arrays.toString(array));

        // 10. Find the missing number in an array (given numbers 1 to N)
        int[] nums = {1, 2, 4, 5};
        int missing = findMissingNumber(nums);
        System.out.println("The missing number in the array is: " + missing);

        // 11. Check if a given string is a palindrome
        String str = "madam";
        boolean isPalindrome = checkPalindrome(str);
        System.out.println("Is the string '" + str + "' a palindrome? " + isPalindrome);

        // 12. Search, Insert, and Delete in a sorted array
        int[] sortedArray = {1, 3, 5, 7, 9};
        int searchValue = 5;
        int searchIndex = binarySearch(sortedArray, searchValue);
        System.out.println("Searching for " + searchValue + ": Found at index " + searchIndex);

        sortedArray = insertSorted(sortedArray, 6);
        System.out.println("Array after inserting 6: " + Arrays.toString(sortedArray));

        sortedArray = deleteFromSorted(sortedArray, 7);
        System.out.println("Array after deleting 7: " + Arrays.toString(sortedArray));
    }

    // 1. Add an element to the array
    public static int[] addElement(int[] array, int value) {
        int[] newArray = Arrays.copyOf(array, array.length + 1);
        newArray[array.length] = value;
        return newArray;
    }

    // 2. Edit an element at a specific index in the array
    public static void editElement(int[] array, int index, int newValue) {
        if (index >= 0 && index < array.length) {
            array[index] = newValue;
        }
    }

    // 3. Delete an element from a specific index in the array
    public static int[] deleteElement(int[] array, int index) {
        if (index < 0 || index >= array.length) {
            return array;  // Invalid index, return original array
        }

        int[] newArray = new int[array.length - 1];
        for (int i = 0, j = 0; i < array.length; i++) {
            if (i != index) {
                newArray[j++] = array[i];
            }
        }
        return newArray;
    }

    // 4. Reverse the array
    public static void reverseArray(int[] array) {
        int start = 0;
        int end = array.length - 1;
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }

    // 5. Find the minimum value in the array
    public static int findMinValue(int[] array) {
        int min = Integer.MAX_VALUE;
        for (int num : array) {
            if (num < min) {
                min = num;
            }
        }
        return min;
    }

    // 6. Find the second maximum value in the array
    public static int findSecondMax(int[] array) {
        int max = Integer.MIN_VALUE;
        int secondMax = Integer.MIN_VALUE;

        for (int num : array) {
            if (num > max) {
                secondMax = max;
                max = num;
            } else if (num > secondMax && num != max) {
                secondMax = num;
            }
        }
        return secondMax;
    }

    // 7. Move zeroes to the end
    public static void moveZeroesToEnd(int[] array) {
        int nonZeroIndex = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] != 0) {
                array[nonZeroIndex++] = array[i];
            }
        }
        while (nonZeroIndex < array.length) {
            array[nonZeroIndex++] = 0;
        }
    }

    // 8. Resize the array
    public static int[] resizeArray(int[] array, int newSize) {
        return Arrays.copyOf(array, newSize);
    }

    // 9. Find the missing number in an array (assumes array is from 1 to N)
    public static int findMissingNumber(int[] nums) {
        int n = nums.length + 1;
        int sum = n * (n + 1) / 2;
        int arraySum = 0;

        for (int num : nums) {
            arraySum += num;
        }

        return sum - arraySum;
    }

    // 10. Check if a string is a palindrome
    public static boolean checkPalindrome(String str) {
        int start = 0;
        int end = str.length() - 1;

        while (start < end) {
            if (str.charAt(start) != str.charAt(end)) {
                return false;
            }
            start++;
            end--;
        }
        return true;
    }

    // 11. Binary Search (to search in a sorted array)
    public static int binarySearch(int[] array, int value) {
        int left = 0;
        int right = array.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid] == value) {
                return mid;
            } else if (array[mid] < value) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1;  // Not found
    }

    // 12. Insert a value into a sorted array
    public static int[] insertSorted(int[] array, int value) {
        int[] newArray = Arrays.copyOf(array, array.length + 1);
        int i = array.length - 1;
        while (i >= 0 && array[i] > value) {
            newArray[i + 1] = array[i];
            i--;
        }
        newArray[i + 1] = value;
        return newArray;
    }

    // 13. Delete a value from a sorted array
    public static int[] deleteFromSorted(int[] array, int value) {
        int index = binarySearch(array, value);
        if (index == -1) {
            return array;  // Value not found
        }

        int[] newArray = new int[array.length - 1];
        for (int i = 0, j = 0; i < array.length; i++) {
            if (i != index) {
                newArray[j++] = array[i];
            }
        }
        return newArray;
    }
}

