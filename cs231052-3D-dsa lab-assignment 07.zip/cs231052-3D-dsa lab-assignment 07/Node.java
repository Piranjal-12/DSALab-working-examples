import java.util.Stack;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class Queue {
    Node front, rear;

    Queue() {
        this.front = this.rear = null;
    }

    void enqueue(int data) {
        Node newNode = new Node(data);
        if (rear == null) {
            front = rear = newNode;
            return;
        }
        rear.next = newNode;
        rear = newNode;
    }

    int dequeue() {
        if (front == null) {
            return -1;
        }
        Node temp = front;
        front = front.next;
        if (front == null) {
            rear = null;
        }
        return temp.data;
    }

    int peek() {
        if (front == null) {
            return -1;
        }
        return front.data;
    }

    void printQueue() {
        Node current = front;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("None");
    }

    void reverseFirstK(int k) {
        if (k <= 0 || front == null) {
            return;
        }

        Stack<Integer> stack = new Stack<>();
        Node current = front;

        for (int i = 0; i < k && current != null; i++) {
            stack.push(current.data);
            current = current.next;
        }

        current = front;

        for (int i = 0; i < k && current != null; i++) {
            current.data = stack.pop();
            current = current.next;
        }
    }

    int getMinimum() {
        if (front == null) {
            return -1;
        }
        int min = front.data;
        Node current = front.next;
        while (current != null) {
            if (current.data < min) {
                min = current.data;
            }
            current = current.next;
        }
        return min;
    }
}
 class Driver {
    public static void main(String[] args) {
        Queue queue = new Queue();

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.enqueue(40);
        queue.enqueue(50);

        System.out.println("Original Queue:");
        queue.printQueue();

        queue.reverseFirstK(3);
        System.out.println("Queue after reversing the first 3 elements:");
        queue.printQueue();

        int minElement = queue.getMinimum();
        System.out.println("Minimum element in the queue: " + minElement);
    }
}
