import java.util.Scanner;

public class NumberOrder {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        int num1 = scanner.nextInt();

        System.out.print("Enter the second number: ");
        int num2 = scanner.nextInt();

        System.out.print("Enter the third number: ");
        int num3 = scanner.nextInt();

        String result = checkOrder(num1, num2, num3);
        System.out.println(result);

        scanner.close();
    }

    public static String checkOrder(int a, int b, int c) {
        if (a < b && b < c) {
            return "increasing";
        } else if (a > b && b > c) {
            return "decreasing";
        } else {
            return "Neither increasing nor decreasing order";
        }
    }
}
