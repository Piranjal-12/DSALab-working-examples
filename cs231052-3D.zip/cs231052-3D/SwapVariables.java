public class SwapVariables {
    private int a;
    private int b;

    public SwapVariables(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public void swap() {
        a = a + b;
        b = a - b;
        a = a - b;
    }

    public void display() {
        System.out.println("a: " + a + ", b: " + b);
    }

    public static void main(String[] args) {
        SwapVariables swapper = new SwapVariables(5, 10);
        System.out.println("Before swap:");
        swapper.display();

        swapper.swap();

        System.out.println("After swap:");
        swapper.display();
    }
}
