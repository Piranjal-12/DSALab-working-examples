public class BinaryTree {

    // Node structure of binary tree
    static class Node {
        int data;
        Node left, right;

        public Node(int data) {
            this.data = data;
            left = right = null;
        }
    }

    // 1. Calculate level (height) of the tree
    public static int calculateLevel(Node root) {
        if (root == null) {
            return 0;
        } else {
            int leftHeight = calculateLevel(root.left);
            int rightHeight = calculateLevel(root.right);
            return Math.max(leftHeight, rightHeight) + 1;
        }
    }

    // 2. Check if tree is full
    public static boolean isFullTree(Node root) {
        if (root == null) {
            return true;
        }
        if (root.left == null && root.right == null) {
            return true;
        }
        if (root.left != null && root.right != null) {
            return isFullTree(root.left) && isFullTree(root.right);
        }
        return false;
    }

    // 2. Check if tree is complete
    public static boolean isCompleteTree(Node root, int index, int numberOfNodes) {
        if (root == null) {
            return true;
        }
        if (index >= numberOfNodes) {
            return false;
        }
        return isCompleteTree(root.left, 2 * index + 1, numberOfNodes) &&
                isCompleteTree(root.right, 2 * index + 2, numberOfNodes);
    }

    // 2. Helper function to count nodes
    public static int countNodes(Node root) {
        if (root == null) {
            return 0;
        }
        return 1 + countNodes(root.left) + countNodes(root.right);
    }

    // 2. Function to check tree type (Full, Complete, or both)
    public static String checkTreeType(Node root) {
        int nodeCount = countNodes(root);
        if (isFullTree(root) && isCompleteTree(root, 0, nodeCount)) {
            return "Both Full and Complete Tree";
        } else if (isFullTree(root)) {
            return "Full Tree";
        } else if (isCompleteTree(root, 0, nodeCount)) {
            return "Complete Tree";
        } else {
            return "Neither Full nor Complete Tree";
        }
    }

    // 3. Check if children sum property holds
    public static boolean isChildrenSumProperty(Node root) {
        if (root == null || (root.left == null && root.right == null)) {
            return true;
        }
        int leftData = (root.left != null) ? root.left.data : 0;
        int rightData = (root.right != null) ? root.right.data : 0;

        if (root.data == leftData + rightData) {
            return isChildrenSumProperty(root.left) && isChildrenSumProperty(root.right);
        }
        return false;
    }

    public static void main(String[] args) {
        Node root = new Node(10);
        root.left = new Node(8);
        root.right = new Node(2);
        root.left.left = new Node(3);
        root.left.right = new Node(5);
        root.right.left = new Node(2);

        System.out.println("Level (Height) of the tree: " + calculateLevel(root));
        System.out.println("Tree type: " + checkTreeType(root));
        System.out.println("Children Sum Property satisfied: " + isChildrenSumProperty(root));
    }
}
